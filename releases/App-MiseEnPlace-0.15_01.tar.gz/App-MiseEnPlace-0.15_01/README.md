# NAME

mise - manage directory and symlink creation, globally and per-project

# VERSION

[![CPAN version](https://badge.fury.io/pl/App-MiseEnPlace.svg)](http://badge.fury.io/pl/App-MiseEnPlace)

# INFO

See
[https://metacpan.org/pod/App::MiseEnPlace](App::MiseEnPlace)
on MetaCPAN.

